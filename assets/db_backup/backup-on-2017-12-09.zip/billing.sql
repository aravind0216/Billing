#
# TABLE STRUCTURE FOR: bhis
#

DROP TABLE IF EXISTS `bhis`;

CREATE TABLE `bhis` (
  `b_id` varchar(90) NOT NULL,
  `date` varchar(90) NOT NULL,
  `pay` double NOT NULL,
  `status` int(80) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: billing
#

DROP TABLE IF EXISTS `billing`;

CREATE TABLE `billing` (
  `b_id` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `role` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `gstin` varchar(90) NOT NULL,
  `stot` double NOT NULL,
  `sgst` double NOT NULL,
  `cgst` double NOT NULL,
  `tot` double NOT NULL,
  `duedate` varchar(100) NOT NULL,
  `mode` varchar(100) NOT NULL,
  `pmode` varchar(100) NOT NULL,
  `advance` double NOT NULL,
  `balance` double NOT NULL,
  `status` int(10) NOT NULL,
  PRIMARY KEY (`b_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: billing_item
#

DROP TABLE IF EXISTS `billing_item`;

CREATE TABLE `billing_item` (
  `b_id` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `product_id` varchar(100) NOT NULL,
  `pname` varchar(100) NOT NULL,
  `s_price` double NOT NULL,
  `qty` double NOT NULL,
  `stot` double NOT NULL,
  `sgst` double NOT NULL,
  `sgst_amt` double NOT NULL,
  `cgst` double NOT NULL,
  `cgst_amt` double NOT NULL,
  `total` double NOT NULL,
  `status` int(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: customer
#

DROP TABLE IF EXISTS `customer`;

CREATE TABLE `customer` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `gstin` varchar(100) NOT NULL,
  `role` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=63 DEFAULT CHARSET=latin1;

INSERT INTO `customer` (`id`, `date`, `name`, `mobile`, `email`, `address`, `gstin`, `role`) VALUES ('62', '2017-12-08', 'Aravind', '8883191962', 'aravind.0216@gmail.com', 'Madurai', '', 'Customer');


#
# TABLE STRUCTURE FOR: fos
#

DROP TABLE IF EXISTS `fos`;

CREATE TABLE `fos` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=61 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: foswork
#

DROP TABLE IF EXISTS `foswork`;

CREATE TABLE `foswork` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `credit` double NOT NULL,
  `debit` double NOT NULL,
  `balance` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: phis
#

DROP TABLE IF EXISTS `phis`;

CREATE TABLE `phis` (
  `p_id` varchar(90) NOT NULL,
  `date` varchar(90) NOT NULL,
  `pay` double NOT NULL,
  `status` int(80) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: product
#

DROP TABLE IF EXISTS `product`;

CREATE TABLE `product` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `pro_id` varchar(90) NOT NULL,
  `date` varchar(100) NOT NULL,
  `p_name` varchar(100) NOT NULL,
  `p_price` int(100) NOT NULL,
  `d_price` double NOT NULL,
  `r_price` double NOT NULL,
  `c_price` double NOT NULL,
  `stock` int(100) NOT NULL,
  `sgst` float NOT NULL,
  `cgst` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: purchase
#

DROP TABLE IF EXISTS `purchase`;

CREATE TABLE `purchase` (
  `p_id` varchar(100) NOT NULL,
  `pdate` varchar(100) NOT NULL,
  `cname` varchar(100) NOT NULL,
  `sname` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `gstin` varchar(90) NOT NULL,
  `stot` double NOT NULL,
  `sgst` double NOT NULL,
  `cgst` double NOT NULL,
  `tot` double NOT NULL,
  `duedate` varchar(100) NOT NULL,
  `mode` varchar(100) NOT NULL,
  `advance` double NOT NULL,
  `balance` double NOT NULL,
  `status` int(10) NOT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: purchase_item
#

DROP TABLE IF EXISTS `purchase_item`;

CREATE TABLE `purchase_item` (
  `p_id` varchar(100) NOT NULL,
  `pdate` varchar(100) NOT NULL,
  `product_id` varchar(100) NOT NULL,
  `pname` varchar(100) NOT NULL,
  `p_price` double NOT NULL,
  `qty` double NOT NULL,
  `stot` double NOT NULL,
  `sgst` double NOT NULL,
  `sgst_amt` double NOT NULL,
  `cgst` double NOT NULL,
  `cgst_amt` double NOT NULL,
  `total` double NOT NULL,
  `status` int(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: register
#

DROP TABLE IF EXISTS `register`;

CREATE TABLE `register` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `user` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `role` varchar(100) NOT NULL,
  `user_img` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;

INSERT INTO `register` (`id`, `name`, `user`, `pass`, `email`, `mobile`, `role`, `user_img`) VALUES ('1', 'Admin', 'admin', 'admin', 'admin@gmail.com', '1234567890', 'Admin', '');


#
# TABLE STRUCTURE FOR: supplier
#

DROP TABLE IF EXISTS `supplier`;

CREATE TABLE `supplier` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `cname` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `gstin` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

